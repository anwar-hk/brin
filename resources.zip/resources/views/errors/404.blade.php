<!DOCTYPE html>
<html>
<head>
  <!-- Site made with Mobirise Website Builder v4.3.2, https://mobirisethemes.com -->
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="generator" content="Mobirise v4.3.2, mobirisethemes.com">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="shortcut icon" href="images/favicon.png" type="image/x-icon">
  <meta name="description" content="">
  <title>Page not found</title>
  <link rel="stylesheet" href="assets/web/assets/mobirise-icons/mobirise-icons.css">
  <link rel="stylesheet" href="assets/tether/tether.min.css">
  <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
  <link rel="stylesheet" href="assets/bootstrap/css/bootstrap-grid.min.css">
  <link rel="stylesheet" href="assets/bootstrap/css/bootstrap-reboot.min.css">
  <link rel="stylesheet" href="assets/theme/css/style.css">
  <link rel="stylesheet" href="assets/mobirise/css/mbr-additional.css" type="text/css">
</head>
<body>
<section class="header11 cid-qwTx7JvHJa mbr-fullscreen" id="header11-1" data-rv-view="1053">

    <!-- Block parameters controls (Blue "Gear" panel) -->
    
    <!-- End block parameters -->

    <div class="mbr-overlay" style="opacity: 0.7; background-color: rgb(99, 90, 81);">
    </div>
    <div class="container align-left">
        <div class="media-container-column mbr-white col-md-12">
            <h3 class="mbr-section-subtitle py-3 mbr-fonts-style display-5"><span style="font-style: normal;">ERROR !</span></h3>
            <h1 class="mbr-section-title py-3 mbr-fonts-style display-1">Oops! Something went wrong...</h1>
            <p class="mbr-text py-3 mbr-fonts-style display-5">The page you're looking for is not available. Please check the URL.</p>
            <div class="mbr-section-btn py-4"><a class="btn btn-md btn-white display-4" onclick='goBack()'>BACK TO SITE</a></div>
        </div>
    </div>
</section>
  <script src="assets/web/assets/jquery/jquery.min.js"></script>
  <script src="assets/popper/popper.min.js"></script>
  <script src="assets/tether/tether.min.js"></script>
  <script src="assets/bootstrap/js/bootstrap.min.js"></script>
  <script src="assets/smooth-scroll/smooth-scroll.js"></script>
  <script src="assets/theme/js/script.js"></script>
  

<script>
function goBack() {
    window.history.back();
}
</script>
  
</body>
</html>