<!--Footer-part-->
  <div class="row-fluid">
  <div id="footer" class="span12"> {{ date('Y') }} &copy; Matrix Admin. Brought to you by <a href="http://themedesigner.in">Themedesigner.in</a> </div>
  <!--end-Footer-part-->